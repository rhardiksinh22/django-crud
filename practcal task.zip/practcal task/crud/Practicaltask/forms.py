from django import forms
from .models import Practicaltask



class Practicaltaskform(forms.ModelForm):
    class Meta:
        model = Practicaltask
        fields="__all__"