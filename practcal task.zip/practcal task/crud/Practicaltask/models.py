from django.db import models

# Create your models here.
class Practicaltask(models.Model):
    Taskname=models.CharField(max_length=20)
    Task_Completions_date=models.DateField()
    Task_description=models.TextField()


