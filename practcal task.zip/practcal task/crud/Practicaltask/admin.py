from django.contrib import admin
from .models import Practicaltask
# Register your models here.
admin.site.register(Practicaltask)