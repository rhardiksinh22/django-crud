from django.shortcuts import render,redirect
from .forms import Practicaltaskform
from .models import Practicaltask
# Create your views here.
def index(request):
    data=Practicaltaskform(request.POST)
    if request.method == "POST":
        if data.is_valid():
            data.save()
            return redirect("home")
        else:
            print('data')
    return render(request,"index.html",{'data':data})

def home(request):
    data= Practicaltask.objects.all()
    return render(request,"home.html",{'data':data})               
def update(request,id):
    data1=Practicaltask.objects.get(id=id)
    data=Practicaltaskform(request.POST or None, instance=data1) 
    if request.method =="POST":
        if data.is_valid():
            data.save()
            return redirect("home")
        else:
            print("error in update")
    return render(request,"update.html",{'data':data})        

def delete(request,id):
    data=Practicaltask.objects.get(id=id)
    if data:
        data.delete()
        return redirect('home')
    else:
        print('data')
    return render(request,"home.html")        
    