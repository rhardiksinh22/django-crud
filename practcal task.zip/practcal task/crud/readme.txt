Project name: CRUD opertions
Project Description: crud in django 
install django: pip install django
run: py manage.py runserver
